java -jar burploader.jar
